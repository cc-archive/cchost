#!/usr/bin/php
<?php
error_reporting(E_ALL);

$meta_dir = empty($argv[1]) ? './' : $argv[1] . '/';

require_once(dirname(__FILE__) .'/podcast_meta.inc');

$head_html       = htmlentities(file_get_contents($meta_dir . 'playlist_head.html'));
$attr_links_html = htmlentities(file_get_contents($meta_dir . 'playlist_attr_links.html'));
$bumpers_html    = htmlentities(file_get_contents($meta_dir . 'playlist_bumper_links.html'));
$add_date = date('Y-m-d H:i:s');
$archive_date = date('Y-m-d H:i:s',$podcast_meta['time']);
$site_tag = preg_replace('/^([^\.]+)\.[a-z]+$/i','\1',$podcast_meta['cchost_site']);
$h = '<';
$h .= '?xml version="1.0" encoding="UTF-8"?';
$h .= '>' . "\n";
$template = $h . <<<EOF
<metadata>
  <mediatype>audio</mediatype>
  <collection>opensource_audio</collection>
  <title>{$podcast_meta['cart_name']}</title>
  <description>&lt;img src="http://{$podcast_meta['cchost_site']}/mixter-files/images/cc-mixter-sq-logo.png" /&gt;
  {$head_html}
  &lt;h3&gt;Track List:&lt;/h3&gt;
  {$attr_links_html} 
  &lt;h3&gt;Bumpers:&lt;/h3&gt;
  {$bumpers_html} 
  &lt;h3&gt;&lt;a href="http://{$podcast_meta['cchost_site']}/podcast"&gt;Podcast home page&lt;/a&gt;&lt;/h3&gt;
  </description>

  <subject>{$site_tag} podcast </subject>
  <creator>{$podcast_meta['user_real_name']}</creator>
  <licenseurl>http://creativecommons.org/licenses/by-nc-sa/3.0/us/</licenseurl>
  <identifier>{$podcast_meta['archive_id']}</identifier>
  <uploader>{$podcast_meta['archive_user']}</uploader>
  <addeddate>{$add_date}</addeddate>
  <publicdate>{$archive_date}</publicdate>
</metadata>
EOF;

$fname = $meta_dir . $podcast_meta['archive_id'] . '_meta.xml';
_write_xml($fname,$template);
$fname = $meta_dir . $podcast_meta['archive_id'] . '_files.xml';
_write_xml($fname,'<files />');

$ftp_script =<<<EOF
mkdir {$podcast_meta['archive_id']}
cd {$podcast_meta['archive_id']}
put {$podcast_meta['archive_id']}.mp3
put {$podcast_meta['archive_id']}_meta.xml
put {$podcast_meta['archive_id']}_files.xml
close
EOF;

$fname = $meta_dir .'ftp_script';
_write_xml($fname,$ftp_script);

function _write_xml($fname,$text)
{
    global $argv;
    
    if( file_exists($fname) ) { unlink($fname); }
    print "[{$argv[0]}] Writing {$fname}\n";
    $f = fopen($fname,'w');
    fwrite($f,$text);
    fclose($f);
}

?>
