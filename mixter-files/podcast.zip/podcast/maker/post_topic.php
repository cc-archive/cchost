#!/usr/bin/php
<?php
/*
#
# Creative Commons has made the contents of this file
# available under a CC-GNU-GPL license:
#
# http://creativecommons.org/licenses/GPL/2.0/
# 
# You may use this software in accordance with the
# terms of that license. You agree that you are solely 
# responsible for your use of the ccHost software and you
# represent and warrant to Creative Commons that your use
# of this software will comply with the CC-GNU-GPL.
#
# author: Victor Stone
# fourstones@sourceforge.net
# May 20, 2009
#
#
*/
error_reporting(E_ALL);

$meta_dir = empty($argv[1]) ? './' : $argv[1] . '/';

require_once(dirname(__FILE__) .'/Snoopy.class.php');
require_once(dirname(__FILE__) .'/podcast_meta.inc');
$archive_id = $podcast_meta['archive_id'];
$url = "http://archive.org/download/{$archive_id}/{$archive_id}.mp3";
$mp3size = filesize($meta_dir . $archive_id . '.mp3');
$fs  = number_format($mp3size/(1024*1024),2);


$topic_text_bb_version =<<<EOF
[query=t=playlist_2_head&ids={$podcast_meta['cart_id']}][/query]

[big][enclosure={$url}]Download podcast ({$fs}MB)[/enclosure][/big]

Songs...

[query=t=links_by&chop=0&playlist={$podcast_meta['cart_id']}&tags=-site_promo+-bumper][/query]

Bumpers...

[query=t=links_by&chop=0&{$podcast_meta['cart_id']}&tags=site_promo+bumper&type=any][/query]
EOF;

$head  = file_get_contents($meta_dir . 'playlist_head.html');
$links = file_get_contents($meta_dir . 'playlist_attr_links.html');
$bumps = file_get_contents($meta_dir . 'playlist_bumper_links.html');

$topic_text =<<<EOF
{$head}
<h3><a rel="enclosure" href="{$url}">Download podcast ({$fs}MB)</a></h3>
<p><b>Songs...</b></p>
{$links}
<p><b>Bumpers...</b></p>
{$bumps}
<!-- enclosure_url%{$url}% enclosure_size%{$mp3size}% enclosure_type%audio/mp3% -->
EOF;

$time = $podcast_meta['time'];
$site = $podcast_meta['cchost_site'];

$post_data = array(
    'topic_type' => 'podcast',
    'new_topic_type' =>  '',
    'topic_date' => array
        (
            'm' => date('F',$time),
            'd' => date('d',$time),
            'y' => date('Y',$time),
            'h' => date('H',$time),
            'i' => date('i',$time),
            'a' => date('a',$time),
        ),
    'topic_name' => $podcast_meta['cart_name'],
    'topic_text' => $topic_text,
    'form_submit' => 'Submit Content',
    'http_referer' => urlencode('http://' . $site),
    'contentpost' => 'classname'
    );

$cookie_data = file_get_contents(dirname(dirname(__FILE__)) . '/cookie_data');
$snoopy = new Snoopy();
$snoopy->cookies['lepsog3'] = urldecode($cookie_data);
print "[{$argv[0]}] Calling {$site}...";
$snoopy->submit('http://'.$site.'/admin/content/post',$post_data);
print "done\n";
//print $snoopy->results;
?>
