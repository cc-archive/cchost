#!/usr/bin/php
<?
error_reporting(E_ALL);

if( empty($argv[1]) )
{
    print <<<EOF
Usage {$argv[0]} FIELD_NAME [dir-name]

default dir-name is "show\"

Where FIELD_NAME is one of:
    archive_id
    archive_user
    artist_page_url
    attr1...n
    browse_tag_url
    cart_date_format
    cart_desc_html
    cart_dynamic
    cart_id
    cart_name
    cart_num_items
    cart_subtype
    cart_tags
    cart_tags_munged
    cart_user
    date
    dl_url
    feed_url
    permalink_url
    share_url
    target'
    time
    user_name
    user_real_name
    year

EOF;
    exit;
}

$meta_dir = empty($argv[2]) ? '' : $argv[2] . '/';
require_once('podcast_meta.inc');
if( !array_key_exists($argv[1],$podcast_meta) )
{
    print "Unknown arg: {$argv[1]}\n";
    exit;
}
print $podcast_meta[$argv[1]]
?>
